// Palco animado das cutscenes: cada efeito usa uma linguagem visual própria.
import { useEffect, useRef } from "react";
import { drawChar } from "@/odyssey/gfx";
import type { EpicScene, StageFx } from "@/odyssey/epic";
import { NPCS } from "@/odyssey/data";

const HERO = { name: "Você", pal: { skin: "#f0c8a0", hair: "#f0d040", body: "#3070c0", legs: "#2a3050" } };
const GORM = NPCS[0]!;

/** Cenas antigas sem palco recebem uma direção determinística, para nunca parecerem iguais. */
export function stageFor(id: string, stage?: EpicScene): EpicScene {
  if (stage) return stage;
  let h = 0; for (const ch of id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const fx: StageFx[] = ["stars", "petals", "embers", "rain", "waves", "spiral", "shards", "duel"];
  return { id, title: "", lines: [], actors: [HERO, { name: GORM.name, pal: GORM.pal }], fx: fx[h % fx.length]!, sky: ["#1a2440", "#3a2050", "#103040", "#402818", "#161f3b"][h % 5]!, ground: ["#3a6a30", "#305a70", "#5a4a3a", "#4a3050"][h % 4]! };
}

type Particle = { x: number; y: number; v: number; phase: number };
const hash = (n: number) => ((n * 1664525 + 1013904223) >>> 0) / 4294967296;

function drawWaves(c: CanvasRenderingContext2D, t: number, color: string) {
  c.strokeStyle = color; c.lineWidth = 1;
  for (let row = 0; row < 5; row++) { c.beginPath(); for (let x = -10; x <= 330; x += 5) c.lineTo(x, 133 + row * 7 + Math.sin(x * 0.08 + t * (2 + row * .2)) * 2); c.stroke(); }
}
function drawHalo(c: CanvasRenderingContext2D, x: number, y: number, t: number, color: string) {
  c.save(); c.translate(x, y); c.rotate(t * .25); c.strokeStyle = color; c.globalAlpha = .8;
  for (let i = 0; i < 3; i++) { c.beginPath(); c.ellipse(0, 0, 22 + i * 7, 7 + i * 3, i * .7, 0, Math.PI * 2); c.stroke(); }
  c.restore();
}

export function CinemaStage({ scene, line }: { scene: EpicScene; line: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const lineRef = useRef(line); lineRef.current = line;
  useEffect(() => {
    const cv = ref.current; const c = cv?.getContext("2d"); if (!cv || !c) return;
    const actors = Array.isArray(scene.actors) && scene.actors.length ? scene.actors : [HERO, { name: GORM.name, pal: GORM.pal }];
    const sky = typeof scene.sky === "string" && scene.sky ? scene.sky : "#1a2440";
    const ground = typeof scene.ground === "string" && scene.ground ? scene.ground : "#203b2b";
    const fx = typeof scene.fx === "string" ? scene.fx : "stars";
    const W = 320, H = 180; c.imageSmoothingEnabled = false;
    const parts: Particle[] = Array.from({ length: 72 }, (_, i) => ({ x: Math.floor(hash(i + 3) * W), y: Math.floor(hash(i + 89) * H), v: 10 + (i % 7) * 6, phase: hash(i + 120) * 7 }));
    let raf = 0; const t0 = performance.now(); let flash = 1;
    const draw = (now: number) => {
      const t = (now - t0) / 1000;
      const quake = fx === "quake" || fx === "duel" ? Math.sin(t * 38) * (fx === "duel" ? .7 : 1.5) : 0;
      c.setTransform(1, 0, 0, 1, 0, 0);
      const g = c.createLinearGradient(0, 0, 0, H); g.addColorStop(0, sky); g.addColorStop(1, fx === "void" ? "#05020d" : "#000"); c.fillStyle = g; c.fillRect(0, 0, W, H);
      const pan = fx === "waves" ? Math.sin(t * .35) * 12 : Math.sin(t * .15) * 20;
      c.fillStyle = "rgba(0,0,0,.38)"; c.beginPath(); c.moveTo(0, 120);
      for (let x = 0; x <= W; x += 20) c.lineTo(x, 100 + Math.sin((x + pan * .5) * .04) * 14); c.lineTo(W, H); c.lineTo(0, H); c.fill();
      c.fillStyle = ground; c.fillRect(0, 128, W, H - 128);
      if (fx === "waves") drawWaves(c, t, "rgba(160,230,255,.5)");
      if (fx === "void") { c.strokeStyle = "rgba(160,100,255,.45)"; for (let r = 8; r < 115; r += 13) { c.beginPath(); c.arc(160, 92, r + Math.sin(t * 2 + r) * 3, t + r * .02, t + Math.PI * 1.4 + r * .02); c.stroke(); } }
      const n = actors.length, speaker = lineRef.current % Math.max(1, n);
      c.save(); c.translate(quake + pan * .3, 0);
      actors.forEach((a, i) => {
        const x = fx === "duel" ? (i === 0 ? 82 : i === n - 1 ? 238 : 160) : W / 2 + (i - (n - 1) / 2) * 70;
        const talking = i === speaker, bob = talking ? Math.abs(Math.sin(t * 6)) * 1.5 : 0;
        const scale = fx === "blessing" && i === n - 1 ? 3.8 : fx === "duel" ? 3.3 : 3;
        c.save(); c.translate(x, 150 - bob); c.scale(scale, scale);
        c.fillStyle = "rgba(0,0,0,.38)"; c.beginPath(); c.ellipse(0, 0, 6, 2, 0, 0, Math.PI * 2); c.fill();
        drawChar(c, 0, 0, a.pal, i < n / 2 ? 3 : 2, talking ? Math.floor(t * 4) % 4 : 0, null, fx === "duel" && talking ? Math.max(0, Math.sin(t * 7)) : 0);
        c.restore();
        if (talking) { c.fillStyle = "rgba(255,230,140,.9)"; c.font = "8px monospace"; c.textAlign = "center"; c.fillText(a.name, x, 88); }
        if (fx === "blessing" && i === n - 1) { drawHalo(c, x, 110, t, "rgba(255,235,150,.8)"); c.fillStyle = "rgba(255,245,190,.12)"; c.beginPath(); c.moveTo(x - 25, 130); c.lineTo(x + 25, 130); c.lineTo(x + 9, 30); c.lineTo(x - 9, 30); c.fill(); }
      });
      if (fx === "duel") { c.strokeStyle = "rgba(255,245,170,.9)"; c.lineWidth = 2; c.beginPath(); c.arc(160, 112, 26 + Math.sin(t * 8) * 4, t, t + 1.8); c.stroke(); c.fillStyle = "#fff1a0"; c.fillRect(157 + Math.sin(t * 8) * 20, 110, 4, 4); }
      c.restore();
      for (const p of parts) {
        if (fx === "rain") { p.y = (p.y + p.v * .25) % H; c.fillStyle = "rgba(160,190,255,.5)"; c.fillRect(p.x, p.y, 1, 4); }
        else if (fx === "embers") { p.y = (p.y - p.v * .05 + H) % H; c.fillStyle = "rgba(255,140,60,.8)"; c.fillRect(p.x + Math.sin(t + p.v) * 3, p.y, 1, 1); }
        else if (fx === "petals") { p.y = (p.y + p.v * .04) % H; p.x = (p.x + .2) % W; c.fillStyle = "rgba(255,170,200,.8)"; c.fillRect(p.x, p.y, 2, 1); }
        else if (fx === "stars" || fx === "blessing") { c.fillStyle = `rgba(255,255,${fx === "blessing" ? 160 : 255},${.3 + .7 * Math.abs(Math.sin(t * 2 + p.phase))})`; c.fillRect(p.x, (p.y - t * (fx === "blessing" ? 8 : 1)) % 110, fx === "blessing" ? 2 : 1, fx === "blessing" ? 2 : 1); }
        else if (fx === "shards") { const y = (p.y + t * p.v * .2) % 130; c.fillStyle = "rgba(150,235,255,.8)"; c.save(); c.translate(p.x, y); c.rotate(t + p.phase); c.fillRect(-2, -2, 4, 4); c.restore(); }
        else if (fx === "spiral") { const r = 10 + ((p.v * 5 + t * 20 + p.phase * 9) % 100); const a = t * .8 + p.phase; c.fillStyle = "rgba(255,210,120,.75)"; c.fillRect(160 + Math.cos(a) * r, 88 + Math.sin(a) * r * .45, 2, 2); }
      }
      if (fx === "flash" && flash > 0) { flash -= .02; c.fillStyle = `rgba(255,255,255,${flash})`; c.fillRect(0, 0, W, H); }
      const v = c.createRadialGradient(W / 2, H / 2, 60, W / 2, H / 2, 200); v.addColorStop(0, "rgba(0,0,0,0)"); v.addColorStop(1, "rgba(0,0,0,.72)"); c.fillStyle = v; c.fillRect(0, 0, W, H);
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw); return () => cancelAnimationFrame(raf);
  }, [scene]);
  return <canvas ref={ref} width={320} height={180} className="cinema-stage" aria-hidden />;
}
